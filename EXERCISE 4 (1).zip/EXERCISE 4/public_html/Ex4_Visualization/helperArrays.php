<?php
$days = array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday');
$weather = array('stormy','raining','sunny','cloudy','clear', 'snowing', 'grey', 'fog');
$moods = array('happy','sad', 'angry','neutral','calm', 'anxious', 'serene','moody','well','hurt');

$events = array('walking in a forest','swimming in the ocean','dining with sibling','taking a nap with a cat','watching rain fall though the window','reading a comic','baking a chocolate cake','rollerskating','reading a comic','planting roses','chomping on carrots','whistling in the wind','walking through a dark tunnel','sunbathing in the desert','visitng a parent for an afternoon','learning a new programming language','running up stairs');

//heler ... note some can be in BOTH ... 
$positive_moods = array('happy','neutral','calm','serene','well');
$negative_moods = array('sad','angry','neutral','calm', 'anxious','moody','hurt');
?>
